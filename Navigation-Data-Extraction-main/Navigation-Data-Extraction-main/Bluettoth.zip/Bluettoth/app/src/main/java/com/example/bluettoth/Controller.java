package com.example.bluettoth;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class Controller extends AppCompatActivity {

    private static final UUID UUID_SERIAL_PORT_SERVICE = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private InputStream inputStream;
    private OutputStream outputStream;

    private TextView textViewReceived;
    private EditText editTextMessage;
    private Button buttonSend,frontbtn,backbtn,rightbtn,leftbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controller);
        frontbtn = (Button) findViewById(R.id.Front);
        backbtn = (Button) findViewById(R.id.Back);
        leftbtn = (Button)  findViewById(R.id.Left);
        rightbtn = (Button) findViewById(R.id.Right);

//        frontbtn.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                sendData("F");
//                return false;
//            }
//        });
        frontbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("F");
            }
        });

//        backbtn.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                sendData("B");
//                return false;
//            }
//        });
        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("B");
            }
        });

//        leftbtn.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                sendData("L");
//                return false;
//            }
//        });
        leftbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("L");
            }
        });

//        rightbtn.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                sendData("R");
//                return false;
//            }
//        });
        rightbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData("R");
            }
        });

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            showToast("Bluetooth is not supported on this device");
            finish();
            return;
        }

        String deviceAddress = getIntent().getStringExtra("device_address");
        BluetoothDevice bluetoothDevice = bluetoothAdapter.getRemoteDevice("00:00:13:00:3B:7C");

        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(UUID_SERIAL_PORT_SERVICE);
            bluetoothSocket.connect();
            inputStream = bluetoothSocket.getInputStream();
            outputStream = bluetoothSocket.getOutputStream();
        } catch (IOException e) {
            showToast("Failed to connect to the device");
            e.printStackTrace();
            finish();
            return;
        }

        textViewReceived = findViewById(R.id.textReceived);
//        editTextMessage = findViewById(R.id.editTextInput);
//        buttonSend = findViewById(R.id.buttonSend);

//        buttonSend.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String message = editTextMessage.getText().toString();
//                if (!message.isEmpty()) {
//                    sendData(message);
//                    editTextMessage.setText("");
//                } else {
//                    showToast("Please enter a message");
//                }
//            }
//        });

        startReceivingData();
    }

    private void startReceivingData() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] buffer = new byte[1024];
                int bytes;
                while (true) {
                    try {
                        bytes = inputStream.read(buffer);
                        final String receivedMessage = new String(buffer, 0, bytes);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textViewReceived.append(receivedMessage);
                            }
                        });
                    } catch (IOException e) {
                        e.printStackTrace();
                        showToast("Failed to receive data");
                        break;
                    }
                }
            }
        }).start();
    }

    private void sendData(String message) {
        try {
            outputStream.write(message.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
            showToast("Failed to send data");
        }
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(Controller.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (inputStream != null) inputStream.close();
            if (outputStream != null) outputStream.close();
            if (bluetoothSocket != null) bluetoothSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
