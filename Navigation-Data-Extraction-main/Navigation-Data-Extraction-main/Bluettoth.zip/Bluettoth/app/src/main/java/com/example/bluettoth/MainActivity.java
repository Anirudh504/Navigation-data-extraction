package com.example.bluettoth;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BLUETOOTH = 1;
    private static final int REQUEST_ACCESS_LOCATION = 2;
    private static final int MY_PERMISSIONS_REQUEST_BLUETOOTH_CONNECT = 1;


    private BluetoothAdapter bluetoothAdapter;
    private final List<String> bluetoothDevices = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private boolean devicesFound = false;
    private final Handler handler = new Handler();

    private final ActivityResultLauncher<Intent> enableBluetoothLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    discoverDevices();
                } else {
                    showToast("Bluetooth must be enabled to scan for devices");
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listview);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bluetoothDevices);
        listView.setAdapter(adapter);

        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        if (bluetoothManager != null) {
            bluetoothAdapter = bluetoothManager.getAdapter();
        }

        if (bluetoothAdapter == null) {
            showToast("Bluetooth is not available");
        } else {
            if (!hasLocationPermission()) {
                requestLocationPermission();
            } else {
                startBluetooth();
            }
        }

//        pairing the device
//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
//                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(bluetoothDevices.get(position));
//                pairWithDevice(device);
//            }
//        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String deviceInfo = bluetoothDevices.get(position);
                String[] parts = deviceInfo.split("\n");
                if (parts.length >= 2) {
                    String deviceAddress = parts[1]; // Assuming address is the second part
                    // Validate Bluetooth address
                    if (BluetoothAdapter.checkBluetoothAddress(deviceAddress)) {
                        BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
                        pairWithDevice(device);
                    } else {
                        showToast("Invalid Bluetooth address: " + deviceAddress);
                    }
                } else {
                    showToast("Invalid device information");
                }
            }
        });

    }

//    private void pairWithDevice(BluetoothDevice device) {
//        try {
//            Method method = device.getClass().getMethod("createBond", (Class[]) null);
//            method.invoke(device, (Object[]) null);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

//    private void pairWithDevice(BluetoothDevice device) {
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return;
//        }
//        if (device.getBondState() == BluetoothDevice.BOND_BONDED) {
//            // Device is already bonded
//            showToast("Device is already paired");
//            Intent i = new Intent(MainActivity.this, Home.class);
//            startActivity(i);
//        } else {
//            // Start the bonding process
//            if (device.createBond()) {
//                showToast("Pairing initiated with " + device.getName());
//                handler.postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        // Code to be executed after the delay
//                        // For example, show a toast message after 2 seconds
//                        Intent i = new Intent(MainActivity.this, Home.class);
//                        startActivity(i);
////                        Toast.makeText(MainActivity.this, "Delayed action", Toast.LENGTH_SHORT).show();
//                    }
//                }, 10000);
//            } else {
//                showToast("Failed to start pairing with " + device.getName());
//            }
//        }
//    }


    private void pairWithDevice(BluetoothDevice device) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            // Request Bluetooth permissions if not granted
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                    MY_PERMISSIONS_REQUEST_BLUETOOTH_CONNECT);
            return;
        }
        String device_address = device.getAddress();

        if (device.getBondState() == BluetoothDevice.BOND_BONDED) {
            // Device is already bonded, navigate to the next activity
            navigateToNextActivity(device_address);
        } else {
            // Start the bonding process
            if (device.createBond()) {
                showToast("Pairing initiated with " + device.getName());
                // You might want to show a progress dialog or indication to the user that pairing is in progress
            } else {
                showToast("Failed to start pairing with " + device.getName());
            }
        }
    }

    private void navigateToNextActivity(String device_address) {
        Intent intent = new Intent(MainActivity.this, Home.class);
        intent.putExtra("device_address",device_address);
        startActivity(intent);
        // Finish the current activity if you don't want to go back to it when pressing back from the next activity
        finish();
    }



    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                REQUEST_ACCESS_LOCATION);
    }

//    private void startBluetooth() {
//        if (!bluetoothAdapter.isEnabled()) {
//            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
//            enableBluetoothLauncher.launch(enableIntent);
//        } else {
//            discoverDevices();
//        }
//    }

    private void startBluetooth() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
            // Request the missing permission.
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.BLUETOOTH_ADMIN},
                    REQUEST_ENABLE_BLUETOOTH);
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                enableBluetoothLauncher.launch(enableIntent);
            } else {
                discoverDevices();
            }
        }
    }


    private void discoverDevices() {
        bluetoothDevices.clear();
        adapter.notifyDataSetChanged();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            showToast("Location permission is required to scan for Bluetooth devices");
            return;
        }

        if (bluetoothAdapter.startDiscovery()) {
            showToast("Scanning for Bluetooth devices...");

            // Schedule a delayed task to check if devices are found after 10 seconds
            handler.postDelayed(() -> {
                if (!devicesFound) {
                    showToast("No Bluetooth devices found");
                }
            }, 10000); // 10 seconds (10000 milliseconds)

            // Register a BroadcastReceiver to listen for discovered devices
            IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            registerReceiver(discoveryReceiver, filter);
        } else {
            showToast("Failed to start Bluetooth discovery");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_ACCESS_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startBluetooth();
            } else {
                showToast("Location permission is required to scan for Bluetooth devices");
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the BroadcastReceiver when the activity is destroyed
        unregisterReceiver(discoveryReceiver);
    }

    // BroadcastReceiver to handle discovered devices
    private final BroadcastReceiver discoveryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // A Bluetooth device is found
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                String deviceName = device.getName();
                if (deviceName == null) {
                    // Handle case where device name is not available
                    deviceName = "Unknown Device"; // Or any other placeholder value
                }

                String deviceAddress = device.getAddress();

                // Add the device to the list
                bluetoothDevices.add(deviceName + "\n" + deviceAddress);
                adapter.notifyDataSetChanged();

                // Set devicesFound flag to true
                devicesFound = true;
            }
        }
    };
}
