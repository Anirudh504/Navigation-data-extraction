package com.example.bluettoth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Home extends AppCompatActivity {

    private Button terminalbtn, controllerBtn;

    // Retrieve the string extra from the intent
    // Set the text of the TextView to the retrieved string


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        String device_address = getIntent().getStringExtra("device_address");
        terminalbtn = (Button) findViewById(R.id.terminal);
        controllerBtn = (Button) findViewById(R.id.Controller);
        terminalbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Home.this,BluetoothTerminalActivity.class);
                System.out.println("Device_address  "+device_address);
                i.putExtra("device_name",device_address);
                startActivity(i);
            }
        });

        controllerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Home.this,Controller.class);
                startActivity(i);
            }
        });
    }
}